# THE CREDIT LINE Tracking credit-funded Al datacenter builds

![](images/8caaffb69d417caf086a101f1e8205bc768f5a9843ae5d44d474a39156e9974c.jpg)

## Datacenter construction credit: differentiation in terms, but not in pricing (yet)

The debt financing markets have been significantly impacted by the artificial intelligence (Al) investment cycle – both in terms of the magnitude and structure of financing. We estimate more than \$600 billion of Al-related debt has been issued since 2024 across the hyperscaler ecosystem and related industries tied to datacenter construction. Of special note is the estimated \$90 billion of USD IG and HY datacenter construction joint-venture (JV) issuance, over that period. This has effectively represented a new category for corporate credit investors, requiring a different approach of credit analysis that is more closely aligned to the project finance market.

While we expect the market size of such issuance to grow meaningfully, unique deal terms have not translated to dispersed performance. Market pricing has instead coalesced in a tight range of yields and spreads for these bonds have behaved more similarly than those for the broader IG and HY market. We suspect, however, that performance will become more dispersed over time, as dealspecific factors—like construction timelines—grow in importance.

## Tracking datacenter builds

Using a dataset tracking datacenter construction, we map projects to construction progress, scope, and potential additional compute capacity. We find datacenter projects tied to syndicated debt appear broadly on schedule, with aggregate construction progress largely tracking expected timelines and little evidence (so far) of persistent delays. We also find datacenter operators participating in such JV debt issues have been better at tracking expected timelines, perhaps reflecting a quality bias accompanying their debt issuance. However, even if variations in construction risk do not become the key differentiator, we see scope for dispersion to increase from refinancing risk and coverage provisions.

## Shamshad Ali

+1(212)902-6712

shamshad.ali@gs.com

Goldman Sachs & Co. LLC

## Hongcen Wei

+1(212)934-4691

hongcen.wei@gs.com

Goldman Sachs & Co. LLC

## Amanda Lynam, CPA

+1(212)934-1895

amanda.lynam@gs.com

Goldman Sachs & Co. LLC

## Arun Manohar

+1(212)902-8763

arun.manohar@gs.com

Goldman Sachs & Co. LLC

## Sara Grut

+44(20)7774-8622

sara.grut@gs.com

Goldman Sachs International

## Spencer Rogers, CFA

+1(801)884-1104

spencer.rogers@gs.com

Goldman Sachs & Co. LLC

## Ben Shumway

+1(801)578-2553

ben.shumway@gs.com

Goldman Sachs & Co. LLC

## Neth Karunamuni

+1(212)934-0799

neth.karunamuni@gs.com

Goldman Sachs & Co. LLC

# 每日报告

每日微信群内分享7+最新重磅报告；

行研报告均为公开版，权利归原作者所有，起点财经仅分发做内部学习。

![](images/be3871e8fea2882ce687a4a11d16b9e5ba01b1ec189cb0e4168666281abd9627.jpg)

扫一扫二维码关注公号回复:“研究报告”加入“起点财经”微信群

## Tracking credit-funded Al datacenter builds

The increased use of debt funding has turned the Al-related buildout into one of the most important themes for credit investors. Public, private, and foreign currency credit markets have all played a role, given the scale and scope of the estimated buildout. And more recently, a new asset class has emerged within the corporate credit market: bankruptcy remote joint-venture (JV) structures, which resemble project finance deals.

Such deals would have typically been serviced in the project finance market. But the depth of the Al-related financing—and the size required for these deals—has pushed this type of financing into the syndicated corporate credit market, where larger deal sizes can be accommodated. In the HY market, these datacenter financings are eligible for index inclusion in widely-tracked indices. In the IG market, however, they are not eligible for index inclusion.

The growth in this debt footprint has followed the increase in total compute needs. More recently, it has also tracked the sharper acceleration in forecasted power demand capacity (in terms of global wattage to come online), as measured by our commodities colleagues (Exhibit 1). That said, players in the Al ecosystem have not typically disclosed the specific use of proceeds for most syndicated debt issued in the buildout. More broadly, private infrastructure and project finance type deals are opaque, by design.

Exhibit 1: Our commodity research colleagues estimate 95 GW of power demand capacity to come online by 2027 Datacenter capacity is a discounted forecast of capacity. More information on the methodology in the note "Power Analyst: US Data Center Power Demand Likely to Surge". Al-related debt is cumulative net debt from Al datacenter joint-venture bonds and other Al-related debt.

![](images/42d81b0f0e56fe520e612cbc31d7a8f1a2945d46f89c668b87073c507fd5ad09.jpg)  
Source: Aterio, Bloomberg, Goldman Sachs Global Investment Research

Against that backdrop, the amount of debt that can be directly mapped to the Al buildout remains small. Since 2H25, there have been roughly \$90 billion of JV debt funding agreements in the USD IG and HY markets tied to datacenter development. These transactions offer an especially useful window into the financing trend because, unlike traditional corporate bond issuance (where the use of proceeds' classification is often broad), these structures typically rely on lockbox arrangements backed by lease cash flows from specific data halls or contracted capacity. In addition, the offering materials associated with these deals often provide enough project-level detail to allow investors to connect debt raised to identifiable compute capacity.

Even though these agreements are more transparent, it is only a fraction of public debt market funding related to Al (again, Exhibit 1). Indeed, the gap between anticipated datacenter compute funded by these agreements and all US datacenter power demand capacity by 2027 remains very large (Exhibit 2). Taken together, we think the sample represented by these JVs are, on their own, a small fraction of the broader buildout, and not necessarily representative. That said, the line of sight from funding costs to project outcomes remains an important thread as investors grapple with the sheer scale of the current, and projected, buildout.

Exhibit 2: Joint-venture deals are only a fraction of current compute, but we believe they contain some important signals  
![](images/9381b160dd415a4bde43e7e559a6d85fc474ae7879fec3a0799c47e638bb4459.jpg)  
Source: Aterio, Goldman Sachs Global Investment Research

## JV documentation varies, but market pricing has largely coalesced

As we have discussed previously, the deal terms across these structures vary meaningfully. Yet, despite these idiosyncrasies, investors have largely traded them as a homogeneous cohort. Yields have generally clustered in a range (Exhibit 3) and spread moves across structures have been more correlated than the broader USD IG and HY markets (Exhibit 4). In our view, that pattern likely reflects the fact that investors have been underwriting a common thematic exposure first, and specific structural differences second. These are not credits levered to the operating performance of an ultimate guarantor in the conventional sense, but they are levered to the same underlying theme: sustained demand for more compute and continued Al investment. We suspect, however, that performance will become more dispersed over time, as deal-specific factors grow in importance. This includes, for example, construction timelines, call protections, leverage restrictions and amortization schedules.

Exhibit 3: Datacenter JV bond yields have clustered between 6-8%  
![](images/97be5827c74e4b7b93ac7ded25712dbb758b7056bf28dcd978c04524a7f7f6b1.jpg)  
Source: Bloomberg, Goldman Sachs Global Investment Research

Exhibit 4: ...and they have traded in greater lockstep than the broader USD IG and HY markets Rolling 1-month average pairwise correlation in 3-day spread change across AI datacenter bonds, USD IG and HY.  
![](images/735194ceb6f78f6afb2d3721d709c0637a56f7a694c9ed172bf4ebdf01632cf7.jpg)  
Source: Bloomberg, iBoxx, Goldman Sachs Global Investment Research

## Tracking deal-level builds

Using data from Aterio on datacenter construction—and information on datacenter construction deals—we tag site builds to bonds, their project operators and ultimate hyperscaler offtake. One important nuance is that the debt attached to a project often covers only part of the total site. A development may include multiple data halls, for example, while lease cash flows securing a given bond may be tied to only a subset of them. For that reason, we distinguish between total project capacity (which we call "debt-affiliated”) and the portion of capacity explicitly included in the debt structure ("debt-mapped"). This matters because many issuers retain the ability to raise additional pari passu debt at the project level, making the broader site build relevant even when the current bond only finances part of it. We also distinguish datacenter operators who have already participated in these syndicated JV debt deals as “affiliated datacenter operators” given existing investor familiarity.

At the aggregate level, we make three observations. First, only a small fraction of the capacity linked to public debt deals is currently online. Based on our estimates, roughly 560 MW are active today, while about 5.3 GW are either active or under construction and expected to be operational by 2027 (Exhibit 5). As a result, the emphasis on construction risk is rightfully salient for many of these structures. While many of the currently active datacenters were likely funded by a mixture of private debt or equity financing, the need to finance construction at scale has driven, we think, the growth of these project finance deals syndicated to a broader (public) credit investor base. As a result, as more deals come online, we expect syndicated debt financing will play a larger role.

## Exhibit 5: Most of the datacenters in debt deals are not yet active, but are being constructed

GW capacity across construction stage for debt-mapped, debt-affiliated (including non-mapped compute in debt deals) and affiliated datacenter operator deals. Active + pro-rata construction based on share of construction completed. Includes datacenters anticipated to be active by 2027.

Datacenter power capacity related to joint-venture deals

![](images/8cace75735ee280850eea14edbde01aeee5f21d2faab7248ba250c0db23c161b.jpg)  
Source: Aterio, Moody's, S&P Ratings Direct, Fitch Ratings, Goldman Sachs Global Investment Research

Second, these syndicated JV debt deals cover only a fraction of the total datacenter capacity that is expected to be online by 2027 (Exhibit 6). Even under a conservative assumption that only the aforementioned "affiliated datacenter operators" return for additional funding, the implied increase in datacenter power capacity financed through those markets would still be a substantial three-fold increase. The quantum of compute yet to come, we think, underpins the patient approach by many investors who will underwrite each deal and allocate only if comfortable on all important criteria needed for comfort financing the project.

## Exhibit 6: Datacenters in debt deals represent a fraction of anticipated power demand capacity

GW capacity anticipated by 2027 for debt-affiliated (including non-mapped compute in debt deals), affiliated datacenter operator deals and all datacenters in the US and globally.

![](images/ea61e60534d19f30a15b39bc50ee8c95c2f861ccca7e4ee4522784887e901b52.jpg)  
Source: Aterio, Moody's, S&P Ratings Direct, Fitch Ratings, Goldman Sachs Global Investment Research

Third, the relative pace of construction has been stable over the past 12 months. Exhibit 7 shows the pace of compute construction has increased roughly linearly on a pro-rata basis based on estimates from Aterio. In aggregate, this shows that visible construction

has thus far been on schedule. In theory this could motivate the tight, relatively uniform pricing observed so far, but the below masks any heterogeneity under the surface and does not hold the construction to an anticipated schedule.

## Exhibit 7: The aggregate pace of construction has been relatively linear, so far

GW of compute for debt-mapped, debt-affiliated (including non-mapped compute in debt deals) and affiliated datacenter operator deals. Timeseries built on monthly assessments of construction progress or activation.

![](images/ca2e6705df0b4787e44b91e11c423dd800ab7581def9ed29d4b60fd8c6b85fcb.jpg)  
Source: Aterio, Moody's, S&P Ratings Direct, Fitch Ratings, Goldman Sachs Global Investment Research

## Deal-level construction timelines

Using the same dataset, we compare measured construction progress with a simple expected timeline. The former is tracked by Aterio using satellite imagery of construction. The latter linearly interpolates progress between the listed activation date when the datacenter first began construction and the project construction date. While we do not expect actual construction to proceed linearly (due to procurement lead times, equipment delivery, site preparation, and power interconnection timelines), we believe a hypothetical linear benchmark is still helpful for assessing project pacing.

In aggregate, we find that construction appears to be roughly on track, but slightly lagging the linear expected benchmark by 275 MW (Exhibit 8). The gap varies across the datacenter projects affiliated with the JV structures, but is only 15MW on average and does not exceed 100MW for any given project (Exhibit 9).

Exhibit 8: In aggregate, datacenter capacity has generally followed, but slightly lagged, the expected timeline

![](images/07699bcaff7521c3901a4e393c0cdae4bed8ccb5bf3a44e02948adc3754bed63.jpg)  
Source: Aterio, Moody's, S&P Ratings Direct, Fitch Ratings, Goldman Sachs Global Investment Research

Exhibit 9: While there is meaningful variation across mapped debt, no debt-funded project lags the expected timeline by more than 100 MW  
![](images/0f5dd05498213a967c6ed8e86f820a44885bd7d5bd84c58fe25c03be714e99fd.jpg)  
Source: Aterio, Moody's, S&P Ratings Direct, Fitch Ratings, Goldman Sachs Global Investment Research

While our commodities colleagues have noted construction delays in datacenter builds, the lack of persistent, significant construction delays in the sample is relatively encouraging for bondholders. Part of this, we think, could be reflected in the datacenter operators which choose to, and are able to, come to market. If we look, instead, at the datacenter operators that have not used this datacenter funding, we find a growing, persistent delay relative to the linear baseline (Exhibit 10). Taken together, this could mean that those operators which have been able to fund datacenter projects in the syndicated debt market are better positioned to deliver on construction. It is also worth keeping note of this quality differential as the market expands, if more operators elect to choose these structures to fund projects.

Exhibit 10: Datacenter operators which have not been a part of JV debt funded datacenter deals are lagging expected build timelines  
![](images/a426e68b471d8076f38475f3bde71af8a25fe21810d50a95db2101e42fab37fd.jpg)  
Source: Aterio, Moody's, S&P Ratings Direct, Fitch Ratings, Goldman Sachs Global Investment Research

## Reasons for dispersion beyond construction risk

Despite the absence of persistent construction delays, at least based on currently visible evidence, we believe investors should still pay close attention to construction risk. We think it remains central, particularly given the importance of completion guarantees, contingency reserves, and insurance against cost overruns. That said, if visible

construction slippage is not yet sufficient to drive major differentiation, investors should increasingly focus on what comes next.

In our view, the next source of dispersion is likely to be refinancing risk and, relatedly, amortization structure. As we noted, debt syndicated in the market reflects only a fraction of total compute expected to be online in the near future. We expect a range of markets will be utilized to finance these assets. Against that backdrop, the ability of current structures to cover both interest and principal and to refinance efficiently will become increasingly important.

Part of our attention here comes from the lack of consensus around the ultimate refinancing channel. While some market participants may be viewing the public ABS market in particular as a likely contender for refinancing cash-flowing datacenters, the discrepancy in size between ABS markets and datacenter funding needs likely means a wider array of markets and investors are needed (Exhibit 11). Some HY structures could also benefit as construction risk rolls-off, potentially pushing ratings higher.

Even in that scenario, however, the outcome would not argue for uniform spread compression. If anything, it would likely intensify differentiation between projects with strong lease coverage, manageable refinancing needs, and conservative structural protections vs. those with heavier back-end risk.

Exhibit 11: The US datacenter ABS market is currently \$44 billion  
![](images/898a132f5857aa8cf502469424c27dcc62f2911e9ef671e84fae9ff53c1f2ea5.jpg)  
Source: Intex, Goldman Sachs Global Investment Research

We thank Patricia Pacheco for her contribution to this report

## Disclosure Appendix

## Reg AC

We, Shamshad Ali, Hongcen Wei, Amanda Lynam, CPA, Arun Manohar, Sara Grut, Spencer Rogers, CFA, Ben Shumway and Neth Karunamuni, hereby certify that all of the views expressed in this report accurately reflect our personal views, which have not been influenced by considerations of the firm's business or client relationships.

Unless otherwise stated, the individuals listed on the cover page of this report are analysts in Goldman Sachs' Global Investment Research division.

Contributing Authors: Shamshad Ali Goldman Sachs & Co. LLC, Hongcen Wei Goldman Sachs & Co. LLC, Amanda Lynam, CPA Goldman Sachs & Co. LLC, Arun Manohar Goldman Sachs & Co. LLC, Sara Grut Goldman Sachs International, Spencer Rogers, CFA Goldman Sachs & Co. LLC, Ben Shumway Goldman Sachs & Co. LLC, Neth Karunamuni Goldman Sachs & Co. LLC.

Unless otherwise stated, the individuals listed in the Contributing Authors disclosure of this report are analysts in Goldman Sachs' Global Investment Research division.

## Disclosures

## Regulatory disclosures

## Disclosures required by United States laws and regulations

See company-specific regulatory disclosures above for any of the following disclosures required as to companies referred to in this report: manager or co-manager in a pending transaction; 1% or other ownership; compensation for certain services; types of client relationships; managed/co-managed public offerings in prior periods; directorships; for equity securities, market making and/or specialist role. Goldman Sachs trades or may trade as a principal in debt securities (or in related derivatives) of issuers discussed in this report.

The following are additional required disclosures: Ownership and material conflicts of interest: Goldman Sachs policy prohibits its analysts, professionals reporting to analysts and members of their households from owning securities of any company in the analyst's area of coverage. Analyst compensation: Analysts are paid in part based on the profitability of Goldman Sachs, which includes investment banking revenues. Analyst as officer or director: Goldman Sachs policy generally prohibits its analysts, persons reporting to analysts or members of their households from serving as an officer, director or advisor of any company in the analyst's area of coverage. Non-U.S. Analysts: Non-U.S. analysts may not be associated persons of Goldman Sachs & Co. LLC and therefore may not be subject to FINRA Rule 2241 or FINRA Rule 2242 restrictions on communications with a subject company, public appearances and trading in securities covered by the analysts.

## Additional disclosures required under the laws and regulations of jurisdictions other than the United States

The following disclosures are those reguired by the jurisdiction indicated, except to the extent already made above pursuant to United States laws and regulations. Australia: Goldman Sachs Australia Pty Ltd and its affiliates are not authorised deposit-taking institutions (as that term is defined in the Banking Act 1959 (Cth)) in Australia and do not provide banking services, nor carry on a banking business, in Australia. This research, and any access to it, is intended only for "wholesale clients" within the meaning of the Australian Corporations Act, unless otherwise agreed by Goldman Sachs. In producing research reports, members of Global Investment Research of Goldman Sachs Australia may attend site visits and other meetings hosted by the companies and other entities which are the subject of its research reports. In some instances the costs of such site visits or meetings may be met in part or in whole by the issuers concerned if Goldman Sachs Australia considers it is appropriate and reasonable in the specific circumstances relating to the site visit or meeting. To the extent that the contents of this document contains any financial product advice, it is general advice only and has been prepared by Goldman Sachs without taking into account a client's objectives, financial situation or needs. A client should, before acting on any such advice, consider the appropriateness of the advice having regard to the client's own objectives, financial situation and needs. A copy of certain Goldman Sachs Australia and New Zealand disclosure of interests and a copy of Goldman Sachs' Australian Sell-Side Research Independence Policy Statement are available at: https://www.goldmansachs.com/disclosures/australia-new-zealand/index.html. Brazil: Disclosure information in relation to CVM Resolution n. 20 is available at https://www.gs.com/worldwide/brazil/area/gir/index.html. Where applicable, the Brazil-registered analyst primarily responsible for the content of this research report, as defined in Article 20 of CVM Resolution n. 20, is the first author named at the beginning of this report, unless indicated otherwise at the end of the text. Canada: This information is being provided to you for information purposes only and is not, and under no circumstances should be construed as, an advertisement, offering or solicitation by Goldman Sachs & Co. LLC for purchasers of securities in Canada to trade in any Canadian security. Goldman Sachs & Co. LLC is not registered as a dealer in any jurisdiction in Canada under applicable Canadian securities laws and generally is not permitted to trade in Canadian securities and may be prohibited from selling certain securities and products in certain jurisdictions in Canada. If you wish to trade in any Canadian securities or other products in Canada please contact Goldman Sachs Canada Inc., an affiliate of The Goldman Sachs Group Inc., or another registered Canadian dealer. Hong Kong: Further information on the securities of covered companies referred to in this research may be obtained on request from Goldman Sachs (Asia) L.L.C. India: Further information on the subject company or companies referred to in this research may be obtained from Goldman Sachs (India) Securities Private Limited, Research Analyst - SEBI Registration Number INH000001493, 10th Floor, Ascent-Worli, Sudam Kalu Ahire Marg, Worli, Mumbai-400 025, India, Corporate Identity Number U74140MH2006FTC160634, Phone +91 22 6616 9000, Fax +91 22 6616 9001. Goldman Sachs may beneficially own 1% or more of the securities (as such term is defined in clause 2 (h) the Indian Securities Contracts (Regulation) Act, 1956) of the subject company or companies referred to in this research report. Registration granted by SEBl and certification from NISM in no way guarantee performance of the intermediary or provide any assurance of returns to investors. Goldman Sachs (India) Securities Private Limited compliance officer and investor grievance contact details, a copy of the annual compliance audit report and other relevant information and disclosures can be found at this link:

https://www.goldmansachs.com/worldwide/india/research-analyst. Japan: See below. Korea: This research, and any access to it, is intended only for "professional investors" within the meaning of the Financial Services and Capital Markets Act, unless otherwise agreed by Goldman Sachs. Further information on the subject company or companies referred to in this research may be obtained from Goldman Sachs (Asia) L.L.C., Seoul Branch. New Zealand: Goldman Sachs New Zealand Limited and its affiliates are neither "registered banks" nor "deposit takers" (as defined in the Reserve Bank of New Zealand Act 1989) in New Zealand. This research, and any access to it, is intended for "wholesale clients" (as defined in the Financial Advisers Act 2008) unless otherwise agreed by Goldman Sachs. A copy of certain Goldman Sachs Australia and New Zealand disclosure of interests is available at: https://www.goldmansachs.com/disclosures/australia-new-zealand/index.html. Russia: Research reports distributed in the Russian Federation are not advertising as defined in the Russian legislation, but are information and analysis not having product promotion as their main purpose and do not provide appraisal within the meaning of the Russian legislation on appraisal activity. Research reports do not constitute a personalized investment recommendation as defined in Russian laws and regulations, are not addressed to a specific client, and are prepared without analyzing the financial circumstances, investment profiles or risk profiles of clients. Goldman Sachs assumes no responsibility for any investment decisions that may be taken by a client or any other person based on this research report. Singapore: Goldman Sachs (Singapore) Pte. (Company Number: 198602165W), which is regulated by the Monetary Authority of Singapore, accepts legal responsibility for this research, and should be contacted with respect to any matters arising from, or in connection with, this research. Taiwan: This material is for reference only and must not be reprinted without permission. Investors should carefully consider their own investment risk. Investment results are the responsibility of the individual investor. United Kingdom: Persons who

would be categorized as retail clients in the United Kingdom, as such term is defined in the rules of the Financial Conduct Authority, should read this research in conjunction with prior Goldman Sachs research on the covered companies referred to herein and should refer to the risk warnings that have been sent to them by Goldman Sachs International. A copy of these risks warnings, and a glossary of certain financial terms used in this report, are available from Goldman Sachs International on request.

European Union and United Kingdom: Disclosure information in relation to Article 6 (2) of the European Commission Delegated Regulation (EU) (2016/958) supplementing Regulation (EU) No 596/2014 of the European Parliament and of the Council (including as that Delegated Regulation is implemented into United Kingdom domestic law and regulation following the United Kingdom's departure from the European Union and the European Economic Area) with regard to regulatory technical standards for the technical arrangements for objective presentation of investment recommendations or other information recommending or suggesting an investment strategy and for disclosure of particular interests or indications of conflicts of interest is available at https://www.gs.com/disclosures/europeanpolicy.html which states the European Policy for Managing Conflicts of Interest in Connection with Investment Research.

Japan: Goldman Sachs Japan Co., Ltd. is a Financial Instrument Dealer registered with the Kanto Financial Bureau under registration number Kinsho 69, and a member of Japan Securities Dealers Association, Financial Futures Association of Japan Type Il Financial Instruments Firms Association, and Investment Management Association of Japan. Sales and purchase of equities are subject to commission pre-determined with clients plus consumption tax. See company-specific disclosures as to any applicable disclosures required by Japanese stock exchanges, the Japanese Securities Dealers Association or the Japanese Securities Finance Company.

## Global product; distributing entities

Goldman Sachs Global Investment Research produces and distributes research products for clients of Goldman Sachs on a global basis. Analysts based in Goldman Sachs offices around the world produce research on industries and companies, and research on macroeconomics, currencies, commodities and portfolio strategy. This research is disseminated in Australia by Goldman Sachs Australia Pty Ltd (ABN 21 006 797 897); in Brazil by Goldman Sachs do Brasil Corretora de Títulos e Valores Mobiliários S.A.; Public Communication Channel Goldman Sachs Brazil: 0800 727 5764 and / or contatogoldmanbrasil@gs.com. Available Weekdays (except holidays), from 9am to 6pm. Canal de Comunicação com o Público Goldman Sachs Brasil: 0800 727 5764 e/ou contatogoldmanbrasil@gs.com. Horário de funcionamento: segunda-feira à sexta-feira (exceto feriados), das 9h às 18h; in Canada by Goldman Sachs & Co. LLC; in Hong Kong by Goldman Sachs (Asia) L.L.C.; in India by Goldman Sachs (India) Securities Private Ltd.; in Japan by Goldman Sachs Japan Co., Ltd.; in the Republic of Korea by Goldman Sachs (Asia) L.L.C., Seoul Branch; in New Zealand by Goldman Sachs New Zealand Limited; in Russia by OOO Goldman Sachs; in Singapore by Goldman Sachs (Singapore) Pte. (Company Number: 198602165W); and in the United States of America by Goldman Sachs & Co. LLC. Goldman Sachs International has approved this research in connection with its distribution in the United Kingdom.

Goldman Sachs International ("GSI"), authorised by the Prudential Regulation Authority ("PRA") and regulated by the Financial Conduct Authority ("FCA") and the PRA, has approved this research in connection with its distribution in the United Kingdom.

European Economic Area: Goldman Sachs Bank Europe SE ("GSBE") is a credit institution incorporated in Germany and, within the Single Supervisory Mechanism, subject to direct prudential supervision by the European Central Bank and in other respects supervised by German Federal Financial Supervisory Authority (Bundesanstalt für Finanzdienstleistungsaufsicht, BaFin) and Deutsche Bundesbank and disseminates research within the European Economic Area.

## General disclosures

This research is for our clients only. Other than disclosures relating to Goldman Sachs, this research is based on current public information that we consider reliable, but we do not represent it is accurate or complete, and it should not be relied on as such. The information, opinions, estimates and forecasts contained herein are as of the date hereof and are subject to change without prior notification. We seek to update our research as appropriate, but various regulations may prevent us from doing so. Other than certain industry reports published on a periodic basis, the large majority of reports are published at irregular intervals as appropriate in the analyst's judgment.

Goldman Sachs conducts a global full-service, integrated investment banking, investment management, and brokerage business. We have investment banking and other business relationships with a substantial percentage of the companies covered by Global Investment Research. Goldman Sachs & Co. LLC, the United States broker dealer, is a member of SIPC (https://www.sipc.org).

Our salespeople, traders, and other professionals may provide oral or written market commentary or trading strategies to our clients and principal trading desks that reflect opinions that are contrary to the opinions expressed in this research. Our asset management area, principal trading desks and investing businesses may make investment decisions that are inconsistent with the recommendations or views expressed in this research.

We and our affiliates, officers, directors, and employees will from time to time have long or short positions in, act as principal in, and buy or sell, the securities or derivatives, if any, referred to in this research, unless otherwise prohibited by regulation or Goldman Sachs policy.

The views attributed to third party presenters at Goldman Sachs arranged conferences, including individuals from other parts of Goldman Sachs, do not necessarily reflect those of Global Investment Research and are not an official view of Goldman Sachs.

Any third party referenced herein, including any salespeople, traders and other professionals or members of their household, may have positions in the products mentioned that are inconsistent with the views expressed by analysts named in this report.

This research is focused on investment themes across markets, industries and sectors. It does not attempt to distinguish between the prospects or performance of, or provide analysis of, individual companies within any industry or sector we describe.

Any trading recommendation in this research relating to an equity or credit security or securities within an industry or sector is reflective of the investment theme being discussed and is not a recommendation of any such security in isolation.

This research is not an offer to sell or the solicitation of an offer to buy any security in any jurisdiction where such an offer or solicitation would be illegal. It does not constitute a personal recommendation or take into account the particular investment objectives, financial situations, or needs of individual clients. Clients should consider whether any advice or recommendation in this research is suitable for their particular circumstances and, if appropriate, seek professional advice, including tax advice. The price and value of investments referred to in this research and the income from them may fluctuate. Past performance is not a guide to future performance, future returns are not guaranteed, and a loss of original capital may occur. Fluctuations in exchange rates could have adverse effects on the value or price of, or income derived from, certain investments.

Certain transactions, including those involving futures, options, and other derivatives, give rise to substantial risk and are not suitable for all investors. Investors should review current options and futures disclosure documents which are available from Goldman Sachs sales representatives or at https://www.theocc.com/about/publications/character-risks.jsp and https://www.goldmansachs.com/disclosures/cftc\_fcm\_disclosures. Transaction costs may be significant in option strategies calling for multiple purchase and sales of options such as spreads. Supporting documentation will be supplied upon request.

Differing Levels of Service provided by Global Investment Research: The level and types of services provided to you by Goldman Sachs Global

Investment Research may vary as compared to that provided to internal and other external clients of GS, depending on various factors including your individual preferences as to the frequency and manner of receiving communication, your risk profile and investment focus and perspective (e.g., marketwide, sector specific, long term, short term), the size and scope of your overall client relationship with GS, and legal and regulatory constraints As an example, certain clients may request to receive notifications when research on specific securities is published, and certain clients may request that specific data underlying analysts' fundamental analysis available on our internal client websites be delivered to them electronically through data feeds or otherwise. No change to an analyst's fundamental research views (e.g., ratings, price targets, or material changes to earnings estimates for equity securities), will be communicated to any client prior to inclusion of such information in a research report broadly disseminated through electronic publication to our internal client websites or through other means, as necessary, to all clients who are entitled to receive such reports.

All research reports are disseminated and available to all clients simultaneously through electronic publication to our internal client websites. Not all research content is redistributed to our clients or available to third-party aggregators, nor is Goldman Sachs responsible for the redistribution of our research by third party aggregators. For research, models or other data related to one or more securities, markets or asset classes (including related services) that may be available to you, please contact your GS representative or go to https://research.gs.com.

Disclosure information is also available at https://www.gs.com/research/hedge.html or from Research Compliance, 200 West Street, New York, NY 10282.

## © 2026 Goldman Sachs.

You are permitted to store, display, analyze, modify, reformat, and print the information made available to you via this service only for your own use. You may not resell or reverse engineer this information to calculate or develop any index for disclosure and/or marketing or create any other derivative works or commercial product(s), data or offering(s) without the express written consent of Goldman Sachs. You are not permitted to publish, transmit, or otherwise reproduce this information, in whole or in part, in any format to any third party without the express written consent of Goldman Sachs. This foregoing restriction includes, without limitation, using, extracting, downloading or retrieving this information, in whole or in part, to train or finetune a machine learning or artificial intelligence system, or to provide or reproduce this information, in whole or in part, as a prompt or input to any such system.

## START YOUR FINANCE

![](images/06bed2ed55692ea7240be3b99cd77b0f8df4426e8dd4fda8b383c615f911f1e1.jpg)

起点财经，网罗天下报告